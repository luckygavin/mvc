<h1>Hello World!</h1>
<?php
	echo 'I am views and value:'.$i;
?>