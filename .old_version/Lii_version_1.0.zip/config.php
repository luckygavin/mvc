<?php
/* 用于数据库链接等的配置 */
/* 用get_config方法即可获得config数组 */
/*function get_config(){
	return array(
		//'base_url'=>preg_replace('','',dirname(__FILE__)),
		'base_url'=>'/yulongxuan',
		//用于数据库链接
		'db'=>array(
			'host'=>'192.168.1.250',
			'dbname'=>'yulong',
			'username'=>'dreamfly',
			'password'=>'zhangmeng',
		),
	);
}*/
class AppConfig{
	//应用根目录
	public static $base_url = '/yulongxuan';
	
	//用于数据库链接
	public static $db = array(
			'host'=>'192.168.1.250',
			'dbname'=>'yulong',
			'username'=>'dreamfly',
			'password'=>'zhangmeng',
		);
	
}
?>