<?php
	echo 'i am views and value:'.$i;
?>